from setuptools import setup, find_packages

setup(
    name="robosen-servo",
    version="0.1.0",
    description="Robosen 串行总线舵机控制库",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.8",
    install_requires=["pyserial>=3.5"],
)
