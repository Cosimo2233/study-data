# robosen-servo

Robosen 串行总线舵机 (伺服舵机) 的 Python 控制库。

支持角度位置控制、连续旋转 (360°) 模式、转速控制。

---

## 目录

- [获取方式](#获取方式)
- [安装方法](#安装方法)
- [硬件接线](#硬件接线)
- [快速开始](#快速开始)
- [API 速查](#api-速查)
- [功能说明](#功能说明)
- [协议参考](#协议参考)

---

## 获取方式

你有两种方式拿到这个包:

### 方式 A: 源码文件夹 (推荐)

拿到 `robosen_servo/` 整个文件夹, 内含:
- `src/robosen_servo/` — 核心源码
- `test_servo.py` — 功能测试脚本
- `README.md` — 本文件
- `pyproject.toml` / `setup.py` — 构建配置
- `dist/` — 预编译的 whl 文件

### 方式 B: whl 文件

拿到 `robosen_servo-0.1.0-py3-none-any.whl`, 一个文件, 直接安装。

---

## 安装方法

### 方法一: 从源码安装

拿到源码文件夹后:

```bash
cd robosen_servo
pip install .
```

### 方法二: 从 whl 文件安装

拿到 `.whl` 文件（在 dist 目录下）后:

```bash
pip install robosen_servo-0.1.0-py3-none-any.whl
```

### 方法三: 可编辑模式安装 (仅限源码文件夹)

开发者模式, 修改源码后即时生效, 无需重复安装:

```bash
cd robosen_servo
pip install -e .
```

### 验证安装

```bash
pip show robosen-servo
```

```
Name: robosen-servo
Version: 0.1.0
Requires: pyserial
```

如看到以上信息则安装成功。如果报错 `pyserial` 未安装, 会自动装好。

### 依赖

- Python >= 3.8
- pyserial >= 3.5 (pip 自动安装)

---

## 硬件接线

该舵机为**三线半双工串行**通信:

| 线 | 说明 |
|----|------|
| 红色 | 5V 电源正极 |
| 黑色 | GND 共地 |
| 白色/黄色 | 信号线 (半双工) |

### 半双工转换

USB 转串口是**全双工**的, 不能直连。需要用转换模块方向隔离。

---

## 快速开始

```python
from robosen_servo import ServoBus

# 创建连接 (串口号按实际修改)
bus = ServoBus("COM7", servo_id=0x09)

# 使能
bus.enable()

# 读位置
pos = bus.read_pos()
print(f"当前位置: {pos}")

# 设角度位置 (其他通道不受影响)
bus.write_one(9, 500)

# 平滑移动
bus.move_to(channel=9, target=800, duration=1.5)

# 连续旋转模式
bus.set_wheel_mode()
bus.spin(80)     # 正转
bus.spin(0)      # 停止
bus.set_angle_mode()  # 退回角度模式

bus.close()
```

或用 `with` 语句自动管理串口:

```python
with ServoBus("COM7") as bus:
    bus.enable()
    print(bus.read_pos())
    bus.write_one(9, 500)
```

---

## API 速查

### 基础控制

| 方法 | 说明 |
|------|------|
| `enable()` | 使能扭矩, 进入角度控制模式 |
| `disable()` | 关闭扭矩, 舵机松弛 |

### 位置读写

| 方法 | 说明 |
|------|------|
| `read_pos()` | 读取当前位置 |
| `sync_pos()` | 从舵机读取实际位置, 更新到缓存 |
| `write_one(ch, val)` | 写单个通道位置, 其他通道保持不变 |
| `write_all([24个值])` | 写全部24通道位置 |
| `move_to(ch, target, duration)` | 平滑移动到目标位置 |

### 连续旋转模式

| 方法 | 说明 |
|------|------|
| `set_wheel_mode()` | 设为连续旋转模式 (360°, 无刷) |
| `set_angle_mode()` | 退回角度控制模式 (自动同步位置缓存) |
| `spin(speed)` | 控制转速: >0 正转, <0 反转, 0=停止, 范围 1~100 |
| `get_speed()` | 返回当前转速 |

### 其他

| 方法 | 说明 |
|------|------|
| `close()` | 关闭串口 |

---

## 功能说明

### 位置缓存

`ServoBus` 内部维护了 24 通道的位置缓存, 保证 `write_one()` 不会影响其他通道:

```python
bus.write_one(9, 500)  # 通道9 → 500, 通道0-8,10-23 保持不变
```

原理: `write_one()` 只修改缓存中目标通道的值, 然后将完整的 24 通道数据通过广播指令一次性发出。

同步缓存的时机:
- `__init__` 构造时自动读取一次
- `sync_pos()` 手动同步
- `set_angle_mode()` 退回角度模式时自动同步

### 零位偏移

**写 0 时舵机不一定回到位置 0**。编码器是绝对式, 0 对应的是物理限位端:

```
写 0   → 读 ~52~56   (机械零位)
写 100 → 读 ~146
写 500 → 读 ~486
写 800 → 读 ~775
```

如果需要精确控制, 可以先读一次零位做偏移补偿:

```python
zero = bus.read_pos()   # 获取当前零位, 例如 56
target = 500 + zero      # 补偿后写入 556
bus.write_one(9, target)
```

### 角度模式 vs 连续旋转模式

```
┌─────────────┐    enable() / set_angle_mode()    ┌─────────────┐
│  角度模式   │ ◄───────────────────────────────── │  连续旋转    │
│ (位置控制)  │                                   │ (360°无刷)   │
│ 有限位      │ ─────────────────────────────────► │ 无限位       │
│ 可写位置    │       set_wheel_mode()             │ 可控制转速   │
└─────────────┘                                   └─────────────┘
```

- 角度模式下 `write_one()` / `move_to()` 控制位置
- 连续旋转模式下 `spin()` 控制转速, 位置写命令无效
- 切换模式后舵机停在当前位置

### 速度控制方式

舵机本身没有速度参数。速度控制通过**增量插值**实现:

```python
move_to(ch=9, target=800, duration=1.5)
# = 分 50 步, 每步间隔 30ms, 从当前位置逐步走到 800
```

步频固定 30ms, duration 决定总步数, 步数越多越平滑。

---

## 协议参考

完整协议文档见同目录下的 [`舵机控制协议文档.md`](./舵机控制协议文档.md), 包含:

- 通信包格式 (FF FF 帧头 + 地址 + 长度 + 数据 + 校验和)
- 全部已验证命令的字节详解
- 校验和算法及示例
- 实测数据与校准表

---

> 基于 Flexo 项目 (https://github.com/ooeoenify/k1) 和 舵机控制抓包数据的逆向分析及实际测试验证。
