"""
Robosen 串行总线舵机控制类

使用示例:
    from robosen_servo import ServoBus

    with ServoBus("COM7") as bus:
        bus.enable()
        pos = bus.read_pos()
        bus.write_one(9, 512)
"""
from __future__ import annotations

import serial
import time
from typing import Sequence

from .exceptions import ServoTimeoutError

# ── 协议常量 ──────────────────────────────────────────────────
ADDR_BROADCAST = 0xFE
NUM_CHANNELS = 24
POS_MIN, POS_MAX = 0, 1023
SPEED_MAX = 100

# ── 命令常量 ──────────────────────────────────────────────────
CMD_READ_POS = 0x03
CMD_WRITE_BROADCAST = 0xFE
CMD_ENABLE = 0x02
CMD_SET_MODE = 0x04
CMD_SPEED = 0x05

# ── 预制指令 ──────────────────────────────────────────────────
_ENABLE = bytes.fromhex("FF FF FE 03 02 01 04")
_DISABLE = bytes.fromhex("FF FF FE 03 02 00 03")


def _cs(data: bytes) -> int:
    return sum(data) & 0xFF


def _make_read_cmd(servo_id: int) -> bytes:
    body = bytes([servo_id, 0x02, CMD_READ_POS])
    return b"\xFF\xFF" + body + bytes([_cs(body)])


def _make_write_cmd(positions: Sequence[int]) -> bytes:
    assert len(positions) == NUM_CHANNELS
    pos_b = b"".join(bytes([(p >> 8) & 0xFF, p & 0xFF]) for p in positions)
    body = bytes([ADDR_BROADCAST, 0x32, CMD_WRITE_BROADCAST]) + pos_b
    return b"\xFF\xFF" + body + bytes([_cs(body)])


def _make_wheel_mode_cmd(servo_id: int) -> bytes:
    body = bytes([servo_id, 0x03, CMD_SET_MODE, 0x01])
    return b"\xFF\xFF" + body + bytes([_cs(body)])


def _make_spin_cmd(servo_id: int, speed: int) -> bytes:
    if speed > 0:
        spd = min(speed, SPEED_MAX)
        spd_bytes = (0x00, spd)
    elif speed < 0:
        spd = min(-speed, SPEED_MAX)
        spd_bytes = (spd, 0x00)
    else:
        spd_bytes = (0x00, 0x00)
    body = bytes([servo_id, 0x04, CMD_SPEED]) + bytes(spd_bytes)
    return b"\xFF\xFF" + body + bytes([_cs(body)])


# ── 主类 ──────────────────────────────────────────────────────


class ServoBus:
    """
    Robosen 串行总线舵机控制

    用法:
        bus = ServoBus("COM7")
        bus.enable()
        bus.write_one(9, 512)
        bus.set_wheel_mode()
        bus.spin(80)
        bus.set_angle_mode()
        bus.close()

    或使用上下文管理器:
        with ServoBus("COM7") as bus:
            ...
    """

    def __init__(
        self,
        port: str,
        baud: int = 115200,
        servo_id: int = 0x09,
        timeout: float = 0.3,
    ):
        self._ser = serial.Serial(
            port=port,
            baudrate=baud,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=timeout,
        )
        self._id = servo_id
        self._speed = 0                     # 转速缓存
        self._pos = [0] * NUM_CHANNELS      # 位置缓存

        # 初始化: 读取当前实际位置写入缓存
        try:
            self._pos[self._id] = self.read_pos()
        except ServoTimeoutError:
            pass

    # ── 上下文管理 ──────────────────────────────────────────

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        """关闭串口"""
        if self._ser and self._ser.is_open:
            self._ser.close()

    # ── 使能 / 禁用 ─────────────────────────────────────────

    def enable(self):
        """使能扭矩, 进入角度控制模式"""
        self._ser.write(_ENABLE)
        time.sleep(0.3)
        self._drain()

    def disable(self):
        """关闭扭矩"""
        self._ser.write(_DISABLE)
        time.sleep(0.1)
        self._drain()

    # ── 读位置 ──────────────────────────────────────────────

    def read_pos(self, timeout_s: float = 0.5) -> int:
        """
        读取舵机当前位置

        :return: 位置值 (0~1023)
        :raises ServoTimeoutError: 舵机无应答
        """
        cmd = _make_read_cmd(self._id)
        self._ser.write(cmd)
        time.sleep(0.06)

        raw = b""
        t0 = time.time()
        while time.time() - t0 < timeout_s:
            chunk = self._ser.read(self._ser.in_waiting or 1)
            if chunk:
                raw += chunk
            else:
                break
            time.sleep(0.01)

        for i in range(len(raw) - 1):
            if raw[i] != 0xFF or raw[i + 1] != 0xFF:
                continue
            if i + 7 >= len(raw):
                break
            dlen = raw[i + 3]
            total = 4 + dlen
            if i + total > len(raw):
                break
            if _cs(raw[i + 2:i + total - 1]) != raw[i + total - 1]:
                continue
            if raw[i + 2] == self._id and raw[i + 4] == 0xA3 and dlen >= 4:
                return (raw[i + 5] << 8) | raw[i + 6]

        raise ServoTimeoutError(
            f"舵机 {self._id:#04x} 无应答 (收到 {len(raw)}B)"
        )

    def sync_pos(self):
        """
        从舵机读取当前位置, 更新到位置缓存

        多舵机场景下, 只更新本舵机对应的通道。
        """
        pos = self.read_pos()
        self._pos[self._id] = pos

    # ── 写位置 ──────────────────────────────────────────────

    def write_all(self, positions: Sequence[int]):
        """
        广播写24通道位置, 并更新缓存

        :param positions: 24个int, 每个0~1023
        """
        assert len(positions) == NUM_CHANNELS, f"需要{NUM_CHANNELS}个位置值"
        self._pos = list(positions)
        cmd = _make_write_cmd(positions)
        self._ser.write(cmd)

    def write_one(self, channel: int, value: int):
        """
        写单个通道位置, 其他通道保持不变

        基于缓存实现: 只修改目标通道的值, 其余沿用上次的值。
        多舵机场景下不会影响其他舵机。

        :param channel: 通道索引 0~23
        :param value:   位置值 0~1023
        """
        value = max(POS_MIN, min(POS_MAX, value))
        self._pos[channel] = value
        self.write_all(self._pos)

    # ── 平滑移动 (增量插值) ────────────────────────────────

    def move_to(
        self,
        channel: int,
        target: int,
        duration: float = 1.0,
    ):
        """
        平滑移动到目标位置 (通过增量插值)

        :param channel:  通道索引
        :param target:   目标位置 0~1023
        :param duration: 期望耗时(秒)
        """
        target = max(POS_MIN, min(POS_MAX, target))
        current = self._pos[channel]
        interval = 0.03
        steps = max(1, int(duration / interval))
        step_size = (target - current) / steps

        for i in range(1, steps + 1):
            pos = int(current + step_size * i)
            self.write_one(channel, pos)
            time.sleep(interval)

        # 最终精确到位
        self.write_one(channel, target)

    # ── 模式切换 ───────────────────────────────────────────

    def set_wheel_mode(self):
        """设为连续旋转模式(360°), 位置限位解除"""
        cmd = _make_wheel_mode_cmd(self._id)
        self._ser.write(cmd)
        time.sleep(0.1)

    def set_angle_mode(self):
        """
        退回角度控制模式, 舵机恢复位置保持

        模式切换后, 自动刷新位置缓存。
        """
        self.enable()
        time.sleep(0.3)
        try:
            self._pos[self._id] = self.read_pos()
        except ServoTimeoutError:
            pass

    # ── 速度控制 ───────────────────────────────────────────

    def spin(self, speed: int):
        """
        控制旋转速度 (需先调用 set_wheel_mode)

        :param speed: >0 正转, <0 反转, =0 停止, 范围 1~100
        """
        self._speed = speed
        cmd = _make_spin_cmd(self._id, speed)
        self._ser.write(cmd)

    def get_speed(self) -> int:
        """返回当前转速缓存值"""
        return self._speed

    # ── 内部 ────────────────────────────────────────────────

    def _drain(self):
        while self._ser.in_waiting:
            self._ser.read(self._ser.in_waiting)
            time.sleep(0.01)
