"""自定义异常"""


class ServoError(Exception):
    """舵机通信基础异常"""


class ServoTimeoutError(ServoError):
    """读超时 — 舵机无应答"""


class PortNotFoundError(ServoError):
    """串口未找到"""
