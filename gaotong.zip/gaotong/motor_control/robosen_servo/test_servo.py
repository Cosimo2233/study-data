"""
robosen-servo 包功能验证脚本
每步操作前按回车执行, 方便肉眼观察效果

写位置后等待1.5s, 确保舵机走完再读数
"""
import sys
import time

from robosen_servo import ServoBus, ServoTimeoutError

PORT = "COM22"
SERVO_ID = 0x09
WAIT = 1.5  # 写位置后等待舵机到位的时间


def section(title):
    print(f"\n{'='*55}")
    print(f" {title}")
    print(f"{'='*55}")


def result(ok: bool, msg: str = ""):
    mark = "OK" if ok else "FAIL"
    print(f"      -> {mark}  {msg}")


def pause(msg="按回车键执行本步操作, 观察舵机运动后继续..."):
    input(f"  ⏎ {msg}")


# ========================================================================

def main():
    if len(sys.argv) > 1:
        global PORT
        PORT = sys.argv[1]

    print(f"串口: {PORT}  舵机ID: {SERVO_ID:#04x}")

    try:
        bus = ServoBus(PORT, servo_id=SERVO_ID)
    except Exception as e:
        print(f"!! 无法打开串口: {e}")
        sys.exit(1)

    # ── 1. 使能 ──────────────────────────────────────────────
    section("1. 使能")

    pause("按回车使能舵机(咔一声)")
    bus.enable()
    time.sleep(0.3)

    try:
        pos = bus.read_pos()
        result(True, f"当前位置 = {pos}")
    except ServoTimeoutError:
        result(False, "读位置失败")

    # ── 2. 位置控制 ──────────────────────────────────────────
    section("2. 位置控制 — 直接跳转")

    for t in [200, 500, 800]:
        pause(f"按回车→写位置 {t}, 观察舵机跳转")
        bus.write_one(9, t)
        time.sleep(WAIT)
        try:
            p = bus.read_pos()
            result(True, f"写 {t} → 读回 {p}")
        except ServoTimeoutError:
            result(False, "无应答")

    # ── 3. 广播写 ─────────────────────────────────────────────
    section("3. 广播写24通道")

    pause("按回车→全部24通道设300")
    bus.write_all([300] * 24)
    time.sleep(WAIT)
    try:
        p = bus.read_pos()
        result(True, f"读回 {p}")
    except ServoTimeoutError:
        result(False, "无应答")

    pause("按回车→全部24通道归零")
    bus.write_all([0] * 24)
    time.sleep(WAIT)
    try:
        p = bus.read_pos()
        result(True, f"读回 {p}")
    except ServoTimeoutError:
        result(False, "无应答")

    # ── 4. 位置模式速度对比 ──────────────────────────────────
    section("4. 位置模式 — move_to 速度对比")
    print("   每次从 0 → 700, 用不同时长完成")

    speeds = [
        (0.5, "极速 0.5s — 飞快到达"),
        (2.0, "中速 2.0s — 可见运动"),
        (5.0, "慢速 5.0s — 慢慢爬"),
    ]

    for dur, label in speeds:
        pause(f"按回车→归零后{label}")
        # 每次先归零, 确保位移量一致
        bus.write_one(9, 0)
        time.sleep(WAIT)
        t0 = time.time()
        bus.move_to(9, 700, duration=dur)
        elapsed = time.time() - t0
        time.sleep(WAIT)
        try:
            p = bus.read_pos()
            result(True, f"指令{dur:.1f}s, 实际{elapsed:.1f}s, 到达{p}")
        except ServoTimeoutError:
            result(False, "无应答")

    # ── 5. 360° 模式 ─────────────────────────────────────────
    section("5. 360° 连续旋转 — 转速对比")

    pause("按回车→进入360°模式(舵机释放限位)")
    bus.set_wheel_mode()
    result(True)

    spin_speeds = [10, 30, 50, 80]

    for spd in spin_speeds:
        pause(f"按回车→正转 speed={spd}, 转5秒后自动停止")
        bus.spin(spd)
        time.sleep(0.2)

        print(f"         {'t':>5s} | {'位置':>6s}")
        print(f"         {'─'*15}")
        t0 = time.time()
        positions = []
        while time.time() - t0 < 5.0:
            time.sleep(0.4)
            try:
                p = bus.read_pos()
                positions.append(p)
                print(f"         {time.time()-t0:5.2f}s | {p:6d}")
            except ServoTimeoutError:
                pass

        bus.spin(0)
        time.sleep(0.3)

        if len(positions) >= 2:
            delta = positions[-1] - positions[0]
            if delta > 500:
                delta -= 1024
            elif delta < -500:
                delta += 1024
            result(True, f"speed={spd:3d}, 5s位移={delta:+d}")
        else:
            result(True)

    # 反转
    pause("按回车→反转 speed=50, 转5秒后自动停止")
    bus.spin(-50)
    time.sleep(0.2)
    t0 = time.time()
    positions = []
    while time.time() - t0 < 5.0:
        time.sleep(0.4)
        try:
            p = bus.read_pos()
            positions.append(p)
            print(f"         {time.time()-t0:5.2f}s | {p:6d}")
        except ServoTimeoutError:
            pass
    bus.spin(0)
    if len(positions) >= 2:
        delta = positions[-1] - positions[0]
        if delta > 500:
            delta -= 1024
        elif delta < -500:
            delta += 1024
        result(True, f"speed={-50:3d}, 5s位移={delta:+d}")
    else:
        result(True)

    # ── 6. 退回角度模式 ──────────────────────────────────────
    section("6. 退回角度模式")

    pause("按回车→退回角度模式, 舵机恢复位置保持")
    bus.set_angle_mode()
    time.sleep(WAIT)
    try:
        p = bus.read_pos()
        result(True, f"退回后位置 = {p}")
    except ServoTimeoutError:
        result(False, "无应答")

    pause("按回车→写位置500, 验证控制已恢复")
    bus.write_one(9, 500)
    time.sleep(WAIT)
    try:
        p = bus.read_pos()
        result(True, f"写500 → 读回 {p}")
    except ServoTimeoutError:
        result(False, "无应答")

    # ── 7. 归位 ──────────────────────────────────────────────
    section("7. 归位")

    pause("按回车→归零")
    bus.write_one(9, 0)
    time.sleep(WAIT)
    try:
        p = bus.read_pos()
        result(True, f"最终位置 = {p}")
    except ServoTimeoutError:
        result(False, "无应答")

    bus.close()
    print(f"\n{'='*55}")
    print(" 全部测试完成")
    print(f"{'='*55}")


if __name__ == "__main__":
    main()
