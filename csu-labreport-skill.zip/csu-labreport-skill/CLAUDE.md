# labreport-skill

中南大学自动化学院实验报告撰写 Skill — 提供将实验指导书、Word 报告模板、照片和手写数据自动填充为完整实验报告的能力。

## 项目结构

```
lab-report-from-template/
├── SKILL.md                           # 技能定义入口（Claude Code Skill）
├── agents/openai.yaml                 # agent 配置（允许隐式调用）
├── assets/
│   └── original_report_template.docx  # 原始实验报告模板（横版，~42×29.7cm）
├── references/
│   └── report-workflow.md             # 工作流约束与常见失败模式
└── scripts/
    └── fill_template_reports.py       # 核心填充脚本（Python）
```

## 核心技能：lab-report-from-template

### 使用方式

通过 Claude Code Skill 机制调用，从实验指导书、用户照片/数据和模板生成报告。也可直接运行脚本：

```powershell
& python <技能目录>/scripts/fill_template_reports.py `
  --config ./reports_config.json `
  --template <技能目录>/assets/original_report_template.docx `
  --out ./已完成报告
```

### JSON 配置格式

```json
{
  "reports": [
    {
      "filename": "实验一_报告.docx",
      "experiment_name": "实验名称",
      "sections": {
        "purpose": ["目的、原理，每条一段"],
        "devices": ["仪器设备"],
        "plan": ["实验方案及实现"],
        "data": ["数据记录、计算和处理"],
        "conclusion": ["结论、误差分析、改进和思考题"]
      },
      "figures": [
        {"label": "原始记录", "path": "图片/record.jpg"},
        {"label": "处理曲线", "path": "生成图表/chart.jpg"},
        {"label": "实时趋势", "path": "图片/trend.jpg"}
      ]
    }
  ]
}
```

### 脚本核心逻辑 (`scripts/fill_template_reports.py`)

1. 打开 DOCX 模板 → 找到第二个表格的 body 单元格 → 定位五段章节标题（一、到五、）
2. 按顺序填充：实验名称 → 目的/原理 → 仪器设备 → 实验方案 → 数据处理（含图片拼合）→ 结论
3. `make_collage()` 将最多 3 张图拼合成一张综合图（原始记录 + 处理曲线 + 实时趋势）
4. `validate_output()` 验证输出文档的页面尺寸与模板一致

### 五大报告章节

| 章节前缀 | sections 键名 | 内容 |
|---|---|---|
| 一、 | purpose | 实验目的与原理 |
| 二、 | devices | 仪器设备 |
| 三、 | plan | 实验方案及实现 |
| 四、 | data | 数据记录、计算和处理（含插图） |
| 五、 | conclusion | 结论、误差分析、改进与思考题回答 |

### 模板要求

- 模板必须包含至少 2 个表格，第二个表格的单元格内包含以"一、"到"五、"开头的段落
- 模板中应有段落以"实验名称"开头（用于填入实验名）
- 页面尺寸、页边距、封面信息、表格边框等均保留不变

### 依赖

- `python-docx` — DOCX 读写
- `Pillow (PIL)` — 图片处理和拼图
- 字体（按优先级）：微软雅黑 → 宋体 → 黑体

### 关键约束

- **保留模板**：不重建页面布局、不改变纸张大小/页边距
- **实验指导书优先**：目的、原理、仪器、步骤、思考题以指导书为准
- **真实数据优先**：使用用户提供的手写记录和截图，不可读时注明假设
- **紧凑图片**：最多 3 张拼为一张综合图，避免多张大图破坏版面
- **内容充实**：包括原理、详细步骤、计算过程、趋势分析、结论、误差分析、改进建议和思考题

## 参考文档

- [SKILL.md](lab-report-from-template/SKILL.md) — 技能定义完整文档
- [report-workflow.md](lab-report-from-template/references/report-workflow.md) — 工作流约束与验证清单
