# labreport-skill
中南大学自动化学院实验报告撰写skill
